import zipfile

def unzip_file(file_name = 'input as string', file_path = 'input as string'):
    
    if file_path is None or '' or ' ':
        raise ValueError('file path must be specified')
    
    with zipfile.ZipFile(file_name, 'r') as zip_ref:
        zip_ref.extractall(file_path)